from django.urls import path
from .views import*
urlpatterns = [
    path('',home,name='home'),
    path('contact/',contact,name='contact'),
    path('about/',about,name='about'),
    path('form/',form,name='form'),
    path('search/',search_form,name='search_form'),
    path('delete/ <int:id>',delete_data,name="delete_data"), 
    path('update/ <int:id>',update,name="update")
]
