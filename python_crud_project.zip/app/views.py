from django.shortcuts import render,redirect
from .models import Student
from django.contrib import messages
from django.db.models import Q
from django.core.mail import send_mail
from django.template.loader import render_to_string
from datetime import datetime
# Create your views here.
def home(request):
    data=Student.objects.filter(Isdelete=False)
    return render(request,'app/home.html',{'data':data})
def contact(request):
    return render(request,'app/contact.html')
def about(request):
    return render(request,'app/about.html')
def form(request):
    if request.method=='POST':
        name=request.POST.get('name')
        age=request.POST.get('age')
        email=request.POST.get('email')
        message=request.POST.get('message')
        date=datetime.now()

        Student.objects.create(name=name,age=age,email=email,message=message)


        subject="python training"
        message=render_to_string('app/msg.html',{'name':name,'date':date})
        from_email='nishanads77@gmail.com'
        recipient_list=[email]
        send_mail(subject,message,from_email,recipient_list,fail_silently=False)
        messages.success(request,f"Hi {name} successfully register check your mail!!!")
       
        return redirect('form')
        
    return render(request,'app/form.html')
def search_form(request):
    finds=''
    if request.method=='POST':
        searched=request.POST['searched']
        finds=Student.objects.filter(Q(name__icontains=searched)|Q(message__contains=searched))
    return render(request,'app/search.html',{'finds':finds})
def delete_data(request,id):
    stu=Student.objects.get(id=id)
    stu.Isdelete=True
    stu.save()
    return redirect('home')

def update(request,id):
    data=Student.objects.get(id=id)
    if request.method=='POST':
        name=request.POST.get('name')
        age=request.POST.get('age')
        email=request.POST.get('email')
        message=request.POST.get('message')

        stu=Student.objects.get(id=id)
        stu.name=name
        stu.age=age
        stu.email=email
        stu.message=message
        stu.save()
        messages.success(request,'successfully update.....!!!')
        return redirect('home')
    return render(request,'app/update.html',{'data':data})